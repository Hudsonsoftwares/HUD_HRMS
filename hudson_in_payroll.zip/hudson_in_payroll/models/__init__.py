# -*- coding: utf-8 -*-
from . import res_company
from . import res_config_settings
from . import hr_employee
from . import hr_contract
from . import hr_payslip
